import * as React from "react";
import { useId, useBoolean } from "@uifabric/react-hooks";
import { Modal } from "office-ui-fabric-react/lib/Modal";
import {
  getTheme,
  mergeStyleSets,
  FontWeights,
} from "office-ui-fabric-react/lib/Styling";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { IIconProps } from "office-ui-fabric-react/lib/Icon";
import { RowAccessor } from "@microsoft/sp-listview-extensibility";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { sp, IItemAddResult } from "@pnp/sp/presets/all";

import "@pnp/sp/items";
import "@pnp/sp/attachments";

const cancelIcon: IIconProps = { iconName: "Cancel" };
export interface IModalPopupProps {
  rows: RowAccessor[];
  spcontext: any;
}
const classNames = mergeStyleSets({
  headerText: {
    fontSize: "16px",
    fontWeight: 600,
  },
});
export const ModalPopup: React.FunctionComponent<IModalPopupProps> = (
  props
) => {

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [isModalOpen, { setTrue: showModal, setFalse: hideModal }] = useBoolean(
    true
  );
  const [success, setSuccess] = React.useState(false);
  const titleId = useId("title");
  const [title, setTitle] = React.useState(props.rows[0] ? props.rows[0].getValueByName('Title') : '');
  const [val1, setVal1] = React.useState(props.rows[0] ? props.rows[0].getValueByName('column1') : '');
  const [val2, setVal2] = React.useState(props.rows[0] ? props.rows[0].getValueByName('column2') : '');
  const [val3, setVal3] = React.useState(props.rows[0] ? props.rows[0].getValueByName('column3') : '');

  /**
   * handles form submit click
   * @param event
   */
  const submitHandler = async (event: { preventDefault: () => void; }): Promise<void> => {
    event.preventDefault();
    try {
      if (props.rows[0]) {
        const i = await sp.web.lists.getByTitle("poc")
          .items.getById(props.rows[0].getValueByName('ID')).update({
            Title: title,
            column1: val1,
            column2: val2,
            column3: val3
          });
      }
      else {
        const iar: IItemAddResult = await sp.web.lists
          .getByTitle("poc")
          .items.add({
            Title: title,
            column1: val1,
            column2: val2,
            column3: val3
          });
      }
      //Once done clear the state      
      setSuccess(true);
      setTitle('');
      setVal1('');
      setVal2('');
      setVal3('');

    } catch (e) {
      //log.error("submitHandler", e);
    }
  };


  return (
    <div>
      <Modal
        titleAriaId={titleId}
        isOpen={isModalOpen}
        onDismiss={hideModal}
        isBlocking={false}
        containerClassName={contentStyles.feedbackContainer}
      >
        <div className={contentStyles.header}>
          <IconButton
            styles={iconButtonStyles}
            iconProps={cancelIcon}
            ariaLabel="Close window"
            onClick={hideModal}
          />
        </div>
        <div className={contentStyles.body}>
          <p>POC list form</p>
          <Stack>
            <Stack.Item>
              <div>
                <p className={classNames.headerText}>
                  Help us to fill all the required values!
                </p>
                <form onSubmit={submitHandler}>
                  <p>
                    <TextField
                      required
                      placeholder="Title"
                      value={title}
                      onChange={(e, newValue) => {
                        setTitle(newValue);
                      }}
                    />
                  </p>
                  <p>
                    <TextField
                      required
                      placeholder="Column1 value"
                      value={val1}
                      onChange={(e, newValue) => {
                        setVal1(newValue);
                      }}
                    />
                  </p>
                  <p>
                    <TextField
                      required
                      placeholder="Column2 value"
                      value={val2}
                      onChange={(e, newValue) => {
                        setVal2(newValue);
                      }}
                    />
                  </p>
                  <p>
                    <TextField
                      multiline
                      rows={5}
                      required
                      placeholder="Please type in your comment"
                      value={val3}
                      onChange={(e, newValue) => {
                        setVal3(newValue);
                      }}
                    />
                  </p>

                  <p>
                    <div style={{ height: "30px" }}>
                      <button
                        style={{ width: "70px", height: "30px", float: "right" }}
                      >
                        Submit
                      </button>
                    </div>
                  </p>
                </form>
                {success && (
                  <p>
                    <MessageBar messageBarType={MessageBarType.success}>
                      {"Item has been saved!"}
                    </MessageBar>
                  </p>
                )}
              </div>
            </Stack.Item>
          </Stack>
        </div>
      </Modal>


    </div>
  );
};

const theme = getTheme();
const contentStyles = mergeStyleSets({
  containerApp: {
    display: "flex",
    flexFlow: "column nowrap",
    alignItems: "stretch",
    width: "600px",
  },
  feedbackContainer: {
    display: "flex",
    flexFlow: "column nowrap",
    alignItems: "stretch",
    width: "600px"
  },
  header: [
    theme.fonts.xLargePlus,
    {
      flex: "1 1 auto",
      borderTop: `4px solid ${theme.palette.themePrimary}`,
      color: theme.palette.neutralPrimary,
      display: "block",
      alignItems: "center",
      textAlign: "right",
      fontWeight: FontWeights.semibold,
    },
  ],
  body: {
    flex: "4 4 auto",
    padding: "0 24px 24px 24px",
    overflowY: "hidden",
    selectors: {
      p: { margin: "14px 0" },
      "p:first-child": { marginTop: 0 },
      "p:last-child": { marginBottom: 0 },
    },
  },

});

const iconButtonStyles = {
  root: {
    color: theme.palette.neutralPrimary,
    marginLeft: "auto",
    marginTop: "4px",
    marginRight: "2px",
  },
  rootHovered: {
    color: theme.palette.neutralDark,
  },
};
