import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { Panel } from 'office-ui-fabric-react/lib/Panel';
import { ModalPopup } from './ModalPopup';
import { RowAccessor } from '@microsoft/sp-listview-extensibility';
import { mergeStyleSets } from 'office-ui-fabric-react/lib/Styling';

export interface IModalPopupProps {
  rows: RowAccessor[];
  spcontext: any;
}

export const LinkPanel: React.FunctionComponent<IModalPopupProps> = (props) => {
  const [isOpen, setIsOpen] = React.useState(true);
  const showApplicationModal = () => {
    const div = document.createElement('div');
    const element: React.ReactElement<{}> = React.createElement(
      ModalPopup,
      {
        rows: props.rows,
        spcontext: props.spcontext
      }
    );
    ReactDOM.render(element, div);
  }
  const contentStyles = mergeStyleSets({
    linkButton: {
      background: "none",
      border: "none",
      padding: "0",
      cursor: "default",
      color: "blue"

    }
  });
  return (
    <div>
      <Panel
        headerText="Links panel"
        isOpen={isOpen}
        onDismiss={() => setIsOpen(false)}
        closeButtonAriaLabel="Close"
      >
        <p>
          <DefaultButton
            id="btnLink1"
            className={contentStyles.linkButton}
            title="First link"
            onClick={() => {
              showApplicationModal();
            }}
            ariaLabel="Firstlink"
            text="First link"
          />
        </p>
        <p>
          <DefaultButton
            id="btnLink2"
            className={contentStyles.linkButton}
            title="Second link"
            onClick={() => {
              showApplicationModal();
            }}
            ariaLabel="secondlink"
            text="Second link"
          />
        </p>
        <p>
          <DefaultButton
            id="btnLink3"
            className={contentStyles.linkButton}
            title="Third link"
            onClick={() => {
              showApplicationModal();
            }}
            ariaLabel="Thirdlink"
            text="Third link"
          />
        </p>
      </Panel>
    </div>
  )
}