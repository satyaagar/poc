import { BaseListViewCommandSet, IListViewCommandSetExecuteEventParameters } from '@microsoft/sp-listview-extensibility';
/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IDialogDemoCommandSetProperties {
    sampleTextOne: string;
    sampleTextTwo: string;
}
export default class DialogDemoCommandSet extends BaseListViewCommandSet<IDialogDemoCommandSetProperties> {
    onInit(): Promise<void>;
    onExecute(event: IListViewCommandSetExecuteEventParameters): void;
    private _onListViewStateChanged;
}
//# sourceMappingURL=DialogDemoCommandSet.d.ts.map