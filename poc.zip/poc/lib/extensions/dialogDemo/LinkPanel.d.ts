import * as React from 'react';
import { RowAccessor } from '@microsoft/sp-listview-extensibility';
export interface IModalPopupProps {
    rows: RowAccessor[];
    spcontext: any;
}
export declare const LinkPanel: React.FunctionComponent<IModalPopupProps>;
//# sourceMappingURL=LinkPanel.d.ts.map