import { BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
import { IColor } from 'office-ui-fabric-react/lib/Color';
export default class ColorPickerDialog extends BaseDialog {
    message: string;
    colorCode: IColor;
    render(): void;
    getConfig(): IDialogConfiguration;
    protected onAfterClose(): void;
    private _submit;
}
//# sourceMappingURL=ColorPickerDialog.d.ts.map