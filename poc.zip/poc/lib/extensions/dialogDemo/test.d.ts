import * as React from 'react';
export default class test extends React.Component<{}, {}> {
    render(): React.ReactElement<{}>;
}
//# sourceMappingURL=test.d.ts.map